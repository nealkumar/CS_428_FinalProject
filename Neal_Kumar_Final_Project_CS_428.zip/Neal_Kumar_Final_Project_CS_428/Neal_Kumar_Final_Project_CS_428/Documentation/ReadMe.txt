Welcome to Tutor Central 2019 -- Version 1.01

INSTALLATION:
	1) In Eclipse IDE, create a new "Java Project"
	2) In the "src" folder, create a new Package called "my_mvc"
	3) You have 2 options for importing the Java:
		a) RECOMMENDED: 
			i. Right-Click the "my_mvc" package you created in Step 2 and select "Import" -> "Archive File". Click NEXT, then BROWSE
			ii. Navigate to "Neal_Kumar_Final_Project_CS_428" -> "Source" -> "jar"
			iii. Select "TutorCentral" and Click OPEN
			iv. Proceed to section "DEPENDENCY INSTALLATION" in this Readme.txt document
		b.) NOT RECOMMENDED:
			i. Navigate to "Neal_Kumar_Final_Project_CS_428" -> "Source" -> "java_files"
			ii. Naviage to "src" -> "my_mvc"
			iii. Select All files (Ctrl + A) and drag it to the "my_mvc" package you created in Step 2.
			iv. Proceed to section "DEPENDENCY INSTALLATION" in this Readme.txt document

DEPENDENCY INSTALLATION:
	-There are 2 main libraries that this software utilizes for proper functionality:
		1) Microsoft JDBC Driver for SQL Server (Minimum JRE MUST be 8)
			-https://docs.microsoft.com/en-us/sql/connect/jdbc/download-microsoft-jdbc-driver-for-sql-server?view=sql-server-2017
		2) JCommon by JFree
			-http://www.jfree.org/jcommon/
	-In addition the links provided above, the dependencies are packaged in the folder "Dependencies"
	-Dependency integration using Eclipse IDE:
		1) Right click PROJECT NAME
		2) Click PROPERTIES
		3) Click JAVA BUILD PATH from left-hand panel
		4) Click ADD EXTERNAL JARS...
		5) Navigate to the .jar file(s) and click OPEN
			-Microsoft JDBC Driver for SQL Server Instructions:
				-Click "sqljdbc_7.0" -> "enu"
				-Select "mssql-jdbc-7.0.jre8"
					-MUST be JRE 8, not JRE 11
				-Click OPEN
			-jFreeChart
				-Click "jfreechart-1.0.19" -> "lib"
				-Select all .jar files (Ctrl + A)
				-Click OPEN
		6) Click APPLY AND CLOSE
	
CREDENTIALS
	-SQL Server Login Credentials:
		-Username: "neal"
		-Password: "Steel2727"
	
CODE BREAKDOWN
	-This program is written in Java with a base Model View Controller structure. Multitudes of design
	 schemes are implemented in order to achieve a high level of maintainability and ease of extensibility.
	-Design Patterns used include: Template Pattern (Models, Views, Controllers, Forms, Factories), 
	 Abstract Factories (SQL interfacting), and Part-Whole Composite (Menus)
		-Coming soon: SQL Strategies which interface with Concrete Factories
	-ALERT: The Main class is "TutorDriver.java"
		-Upon initially starting the program, this Class MUST be the active class, or the code cannot compile.

CHANGE LOG:
	-Release 1.01: Bug fixes, Encrypted Message Storage, Server Login
		-IMPORTANT NOTE: From this point forward, the Server Login Form MUST
		 be completed before accessing features on the "Main Control", or the 
		 program will freeze and the application will need to be restarted
			-ALERT: Login Credentials may need to be entered twice for 
			 successful authentication. This is a known issue.
	-Release 1.00: Intial public release

SEE ALSO:
	-PointsBreakdown.txt under documentation