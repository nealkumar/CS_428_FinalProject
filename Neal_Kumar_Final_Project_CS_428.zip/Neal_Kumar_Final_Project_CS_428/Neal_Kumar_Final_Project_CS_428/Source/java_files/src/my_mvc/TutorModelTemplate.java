package my_mvc;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

public abstract class TutorModelTemplate extends Observable {

	String applicationTitle, chartTitle;
	private TutorControllerTemplate controller;

	// getter and setter methods
	protected final String getChartTitle() {
		return chartTitle;
	}

	protected final void setChartTitle(String chartTitle) {
		this.chartTitle = chartTitle;
	}

	protected final void setApplicationTitle(String applicationTitle) {
		this.applicationTitle = applicationTitle;
	}

	protected final String getApplicationTitle() {
		return applicationTitle;
	}

	protected final void startBarChartDemo(String applicationTitle, String chartTitle) {
		createDemoBarChart();
	}

	protected final void createDemoBarChart() {
		TutorBarChartDemoView.getInstance(applicationTitle, chartTitle);
	}

	protected final void createNewInsertNewTutorFormView(TutorControllerTemplate controller) {
		this.setController(controller);
		try {
			new InsertNewTutorFormView(getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewDeleteExistingTutorFormView(TutorControllerTemplate controller) {
		this.setController(controller);
		try {
			int[] bounds = { 10, 10, 800, 250 };
			new DeleteExistingTutorFormView(this.getController(), bounds, "Remove Existing Tutor Form");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewInsertNewTutorClientFormView(TutorControllerTemplate controller) {
		this.setController(controller);
		try {
			int[] bounds = { 100, 100, 750, 500 };
			new InsertNewTutorClientFormView(getController(), bounds, "Insert New Client Form");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewDeleteExistingTutorClientFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			int[] bounds = { 10, 10, 800, 250 };
			new DeleteExistingTutorClientFormView(this.getController(), bounds, "Remove Existing Client Form");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewInsertNewTutorPlatformFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			int[] bounds = { 100, 100, 750, 500 };
			new InsertNewTutorPlatformFormView(getController(), bounds, "Insert New Tutoring Platform Form");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewDeleteExistingTutorPlatformFormView(TutorControllerTemplate controller) {
		this.setController(controller);
		try {
			int[] bounds = { 10, 10, 800, 250 };
			new DeleteExistingTutorPlatformFormView(getController(), bounds, "Remove Existing Tutoring Platform Form");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewInsertNewTutorEventFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			int[] bounds = { 100, 100, 1000, 750 };
			new InsertNewTutoringEventFormView(getController(), bounds, "Insert New Tutoring Event Form");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewDeleteExistingTutorEventFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			int[] bounds = { 10, 10, 800, 250 };
			new DeleteExistingTutoringEventFormView(getController(), bounds, "Remove Existing Tutoring Event Form");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createBarChartCountClientsCountTutors(TutorControllerTemplate controller) {
		this.setController(controller);
		try {
			new TutorBarChartTutorEventsCountClientsCountTutorsView("Total Clients and Total Tutors", getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createBarChartCountTutorsCountPlatforms(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			new TutorBarChartCountTutorsCountPlatformsView("Total Tutors and Total Platforms", getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createBarChartCountTutorsCountEvents(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			new TutorBarChartCountTutorsCountEventsView("Total Tutors and Total Events", getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createBarChartCountClientsCountPlatforms(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			new TutorBarChartCountClientsCountPlatformsView("Total Clients and Total Platforms", getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createBarChartCountClientsCountEvents(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			new TutorBarChartCountClientsCountEventsView("Total Clients and Total Events", getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createBarChartCountPlatformsCountEvents(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			new TutorBarChartCountPlatformsCountEventsView("Total Platforms and Total Events", getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createBarChartCountAll(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			new TutorBarChartCountAllView("Total Clients, Total Platforms, Total Events, and Total Tutors",
					getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void newStopwatchMiniView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			new StopwatchMiniView(getController());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewAddEncryptedMessageView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			int[] bounds = { 10, 10, 750, 500 };
			new InsertNewEncryptedMessageView(getController(), bounds, "Add New Encrypted Message");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void viewExisingEncryptedMessageView(TutorControllerTemplate controller) {
		this.setController(controller);
		try {
			int[] bounds = { 10, 10, 750, 500 };
			new CheckExistingEncryptedMessageView(getController(), bounds,
					"Decrypt Existing Message From Yourself Or Another Tutor");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final void createNewServerLoginView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		this.setController(controller);
		try {
			int[] bounds = { 10, 10, 750, 500 };
			new ServerLoginView(getController(), bounds, "Server Login");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected final int getClientIDCount() {
		int count = (int) SqlFactory.executeStatementWithReturn("TUTOR_CLIENTS", "SELECT", "COUNT", null, false);
		return count;
	}

	protected final int getTutorIDCount() {
		// TODO Auto-generated method stub
		int count = 0;
		count = (int) SqlFactory.executeStatementWithReturn("TUTORS", "SELECT", "COUNT", null, false);
		return count;
	}

	public int getPlatformIDCount() {
		// TODO Auto-generated method stub
		int count = (int) SqlFactory.executeStatementWithReturn("TUTOR_PLATFORMS", "SELECT", "COUNT", null, false);
		return count;
	}

	public int getEventIDCount() {
		// TODO Auto-generated method stub
		int count = (int) SqlFactory.executeStatementWithReturn("TUTOR_EVENTS", "SELECT", "COUNT", null, false);
		return count;
	}

	protected final void insertNewTutor(String firstName, String lastName) {
		List<String> l = new ArrayList<String>();
		l.add(firstName);
		l.add(lastName);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTORS", "INSERT", null, l, false);
		System.out.println(success);
	}

	protected void insertNewClient(String clientFirstName, String clientLastName, String clientRating) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(clientFirstName);
		list.add(clientLastName);
		list.add(clientRating);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTOR_CLIENTS", "INSERT", null, list, false);
		System.out.println(success);
	}

	protected final void insertNewPlatform(String platformName, String platformRate, String platformDescription) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(platformName);
		list.add(platformRate);
		list.add(platformDescription);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTOR_PLATFORMS", "INSERT", null, list, false);
		System.out.println(success);
	}

	protected final void insertNewEvent(String tutorID, String clientID, String platformID, String tutoringTotalMins,
			String day, String month, String year, String estimatedPay, String estimatedTax) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(tutorID);
		list.add(clientID);
		list.add(platformID);
		list.add(tutoringTotalMins);
		list.add(day);
		list.add(month);
		list.add(year);
		list.add(estimatedPay);
		list.add(estimatedTax);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTOR_EVENTS", "INSERT", null, list, false);
		System.out.println(success);
	}

	protected final void insertNewEncryptedMessage(String tutorID, String message) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(tutorID);
		list.add(message);
		String success = (String) SqlFactory.executeStatementWithReturn("ENCRYPTED_MESSAGE", "INSERT", null, list,
				false);
		System.out.println(success);
	}

	protected final void deleteExistingTutor(String firstName, String lastName) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(firstName);
		list.add(lastName);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTORS", "DELETE", null, list, false);
		System.out.println(success);
	}

	protected final void deleteExistingClient(String firstName, String lastName) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(firstName);
		list.add(lastName);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTOR_CLIENTS", "DELETE", null, list, false);
		System.out.println(success);
	}

	protected final void deleteExistingPlatform(String platformName, String platformRate) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(platformName);
		list.add(platformRate);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTOR_PLATFORMS", "DELETE", null, list, false);
		System.out.println(success);
	}

	protected void deleteExistingEvent(String eventID) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(eventID);
		String success = (String) SqlFactory.executeStatementWithReturn("TUTOR_EVENTS", "DELETE", null, list, false);
		System.out.println(success);
	}

	@SuppressWarnings("unchecked")
	protected final List<String> generateTheTutorsList(List<String> tutorsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		tutorsList = (List<String>) SqlFactory.executeStatementWithReturn("TUTORS", "SELECT", "return", null,
				idNumberOnly);
		return tutorsList;
	}

	@SuppressWarnings("unchecked")
	protected List<String> generateTheClientsList(List<String> clientsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		clientsList = (List<String>) SqlFactory.executeStatementWithReturn("TUTOR_CLIENTS", "SELECT", "return", null,
				idNumberOnly);
		return clientsList;
	}

	@SuppressWarnings("unchecked")
	protected List<String> generateThePlatformsList(List<String> platformsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		platformsList = (List<String>) SqlFactory.executeStatementWithReturn("TUTOR_PLATFORMS", "SELECT", "return",
				null, idNumberOnly);
		return platformsList;
	}

	@SuppressWarnings("unchecked")
	public List<String> generateTheEventsList(List<String> eventsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		eventsList = (List<String>) SqlFactory.executeStatementWithReturn("TUTOR_EVENTS", "SELECT", "return", null,
				idNumberOnly);
		return eventsList;
	}

	@SuppressWarnings("unchecked")
	public List<String> generateTheMessagesList(List<String> messageList, boolean idNumberOnly) {
		messageList = (List<String>) SqlFactory.executeStatementWithReturn("ENCRYPTED_MESSAGE", "SELECT", "return",
				null, idNumberOnly);
		return messageList;
	}

	protected String searchTutorsForFullNameByID(String selectedItem) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(selectedItem);
		String fullName = (String) SqlFactory.executeStatementWithReturn("TUTORS", "SELECT", "return_special", list,
				false);
		return fullName;
	}

	protected String searchTutorClientsForFullNameByID(String selectedItem) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(selectedItem);
		String fullName = (String) SqlFactory.executeStatementWithReturn("TUTOR_CLIENTS", "SELECT", "return_special",
				list, false);
		return fullName;
	}

	public String searchTutorPlatformsForFullNameByID(String selectedItem) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add(selectedItem);
		String fullName = (String) SqlFactory.executeStatementWithReturn("TUTOR_PLATFORMS", "SELECT", "return_special",
				list, false);
		return fullName;
	}

	protected final void setDbUserNameAndPassword(String userName, String password) {
		// TODO Auto-generated method stub
		TutorConstants.LOGIN_NAME = userName;
		TutorConstants.PASSWORD = password;
		System.out.println("Username: " + TutorConstants.LOGIN_NAME);
		System.out.println("Password: " + TutorConstants.PASSWORD);
	}

	private TutorControllerTemplate getController() {
		return controller;
	}

	private void setController(TutorControllerTemplate controller) {
		this.controller = controller;
	}

}
