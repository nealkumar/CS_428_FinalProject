package my_mvc;

import org.jfree.data.category.CategoryDataset;

public interface TutorChart {

	public CategoryDataset createDataset();

}
