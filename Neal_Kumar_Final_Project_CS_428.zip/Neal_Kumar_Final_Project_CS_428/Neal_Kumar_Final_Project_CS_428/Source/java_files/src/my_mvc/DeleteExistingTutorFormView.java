package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DeleteExistingTutorFormView extends FormViewTemplate {

	// private TutorControllerTemplate controller;
	private List<String> tutorsList;

	public DeleteExistingTutorFormView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
		// this.controller = super.controller;
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		tutorsList = new ArrayList<String>();
		tutorsList = controller.generateAllTutorsList(tutorsList, false);

		JComboBox<String> comb = new JComboBox<String>();
		comb.setBounds(175, 100, 200, 25);
		for (String s : tutorsList) {
			comb.addItem(s);
		}
		contentPane.add(comb);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(480, 100, 125, 25);
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String currentSelection = (String) comb.getSelectedItem();
				System.out.println(currentSelection);
				List<String> fNameLName = new ArrayList<String>();
				fNameLName = breakUpStatement(currentSelection, fNameLName);
				controller.removeExistingTutor(fNameLName.get(1), fNameLName.get(0));
				// doesn't actually re-query the db to reflect changes... only deletes it from
				// the combo-box... kind of hacky, but can be updated later... TODO
				comb.removeItemAt(comb.getSelectedIndex());
			}

		});
		contentPane.add(btnSubmit);
	}

	@Override
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblRemoveExistingTutor = new JLabel("Remove Existing Tutor Form");
		lblRemoveExistingTutor.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblRemoveExistingTutor.setBounds(175, 15, 450, 50);
		contentPane.add(lblRemoveExistingTutor);
	}

	private List<String> breakUpStatement(String currentSelection, List<String> fNameLName) {
		// TODO Auto-generated method stub
		fNameLName = Arrays.asList(currentSelection.split(",[ ]*"));
		return fNameLName;
	}

}
