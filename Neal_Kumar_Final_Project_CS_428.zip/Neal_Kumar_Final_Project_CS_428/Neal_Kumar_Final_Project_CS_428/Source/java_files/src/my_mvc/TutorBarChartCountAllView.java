package my_mvc;

import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class TutorBarChartCountAllView extends TutorBarChartViewTemplate {

	private int clientIDCount = 0, tutorIDCount = 0, eventIDCount = 0, platformIDCount = 0;
	private static final long serialVersionUID = 1L;

	public TutorBarChartCountAllView(String title, TutorControllerTemplate controller) {
		super(title, controller);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		final String totalTutors = "Total Tutors";
		final String totalPlatforms = "Total Platforms";
		final String totalClients = "Total Clients";
		final String totalEvents = "Total Events";
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		platformIDCount = getController().getPlatformsIDCount();
		tutorIDCount = getController().getTutorIDCount();
		clientIDCount = getController().getClientIDCount();
		eventIDCount = getController().getEventIDCount();

		dataset.addValue(tutorIDCount, totalTutors, totalTutors);
		dataset.addValue(platformIDCount, totalPlatforms, totalPlatforms);
		dataset.addValue(clientIDCount, totalClients, totalClients);
		dataset.addValue(eventIDCount, totalEvents, totalEvents);

		return dataset;
	}

}
