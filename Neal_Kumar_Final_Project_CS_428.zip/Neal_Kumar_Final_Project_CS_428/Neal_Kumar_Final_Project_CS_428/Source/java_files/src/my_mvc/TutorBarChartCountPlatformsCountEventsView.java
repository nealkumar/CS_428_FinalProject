package my_mvc;

import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class TutorBarChartCountPlatformsCountEventsView extends TutorBarChartViewTemplate {

	private int platformIDCount = 0, eventIDCount = 0;
	private static final long serialVersionUID = 1L;

	public TutorBarChartCountPlatformsCountEventsView(String title, TutorControllerTemplate controller) {
		super(title, controller);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		final String totalPlatforms = "Total Platforms";
		final String totalEvents = "Total Events";
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		platformIDCount = getController().getPlatformsIDCount();
		eventIDCount = getController().getEventIDCount();

		dataset.addValue(platformIDCount, totalPlatforms, totalPlatforms);
		dataset.addValue(eventIDCount, totalEvents, totalEvents);

		return dataset;
	}

}
