package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertNewTutorPlatformFormView extends FormViewTemplate {

	private JTextField platformNameTextField;
	private JTextField platformRateTextField;
	private JTextField platformDescriptionTextField;

	public InsertNewTutorPlatformFormView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub
		platformNameTextField = new JTextField();
		platformNameTextField.setBounds(294, 140, 232, 20);
		contentPane.add(platformNameTextField);
		platformNameTextField.setColumns(10);
		textFields.add(platformNameTextField);

		platformRateTextField = new JTextField();
		platformRateTextField.setBounds(294, 193, 232, 20);
		contentPane.add(platformRateTextField);
		platformRateTextField.setColumns(10);
		textFields.add(platformRateTextField);

		platformDescriptionTextField = new JTextField();
		platformDescriptionTextField.setBounds(294, 256, 400, 100);
		contentPane.add(platformDescriptionTextField);
		platformDescriptionTextField.setColumns(10);
		textFields.add(platformDescriptionTextField);
	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblAddNewPlatform = new JLabel("Add New Tutoring Platform Form");
		lblAddNewPlatform.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblAddNewPlatform.setBounds(135, 11, 550, 40);
		contentPane.add(lblAddNewPlatform);

		JLabel lblPlatformName = new JLabel("Platform Name: ");
		lblPlatformName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblPlatformName.setBounds(146, 134, 138, 30);
		contentPane.add(lblPlatformName);

		JLabel lblPlatformRate = new JLabel("Tutoring Rate:");
		lblPlatformRate.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblPlatformRate.setBounds(146, 191, 138, 23);
		contentPane.add(lblPlatformRate);

		JLabel lblPlatformDescription = new JLabel("Platform Description:");
		lblPlatformDescription.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblPlatformDescription.setBounds(146, 248, 155, 23);
		contentPane.add(lblPlatformDescription);
	}

	@Override
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JButton btnClear = new JButton("CLEAR");
		btnClear.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnClear.setBounds(193, 414, 127, 23);
		btnClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearJTextFields(); // NOTE: THIS IS A VIOLATION OF THE TEMPLATE PATTERN!!
			}
		});
		contentPane.add(btnClear);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(393, 414, 127, 23);
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!platformNameTextField.getText().equals(null) && !platformRateTextField.getText().equals(null)
						&& !platformDescriptionTextField.getText().equals(null)) {
					// TODO Auto-generated method stub
					controller.insertNewPlatform(platformNameTextField.getText(), platformRateTextField.getText(),
							platformDescriptionTextField.getText());
					JOptionPane.showMessageDialog(null, "New Platform Added to the Database!");
					clearJTextFields(); // NOTE: THIS IS A VIOLATION OF THE TEMPLATE PATTERN!!
				} else {
					JOptionPane.showMessageDialog(null,
							"Platform Name, Platform Rate (int), and Platform Description cannot be blank! Please Try again.",
							"Not Enough Data", 0);
				}
			}
		});
		contentPane.add(btnSubmit);
	}

}
