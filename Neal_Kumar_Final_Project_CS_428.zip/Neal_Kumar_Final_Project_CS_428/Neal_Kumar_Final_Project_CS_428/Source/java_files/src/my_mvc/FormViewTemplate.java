package my_mvc;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.jfree.ui.RefineryUtilities;

public abstract class FormViewTemplate {

	private JPanel contentPane;
	protected List<JTextField> textFields;
	protected JFrame frame;
	private String frameName;
	protected int[] bounds = new int[4];
	protected TutorControllerTemplate controller;

	/**
	 * Constructor is the template method
	 * 
	 * @param controller
	 * @param bounds
	 * @param frameName
	 */
	public FormViewTemplate(TutorControllerTemplate controller, int[] bounds, String frameName) {
		this.controller = controller;
		this.bounds = bounds;
		this.frameName = frameName;
		this.frame = setupFrame(this.frame, this.contentPane, this.bounds, this.frameName);
		this.contentPane = setupPanel(this.frame, this.contentPane);
		this.textFields = new ArrayList<JTextField>();
		addPanelJLabels(this.contentPane);
		addPanelJTextFields(this.textFields, this.contentPane);
		addPanelJButtons(this.contentPane);
		this.frame.setVisible(true);
	}

	private final JFrame setupFrame(JFrame frame, JPanel contentPane, int[] bounds, String formName) {
		frame = new JFrame(formName);
		frame.setBounds(bounds[0], bounds[1], bounds[2], bounds[3]);
		frame.setDefaultCloseOperation(2);
		frame.setPreferredSize(new Dimension(bounds[2], bounds[3]));
		RefineryUtilities.centerFrameOnScreen(frame);
		frame.pack();
		return frame;
	}

	private final JPanel setupPanel(JFrame frame, JPanel contentPane) {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		return contentPane;
	}

	/**
	 * Every new JTextField MUST be added to textFields for proper clearing behavior
	 * 
	 * @param textFields
	 * @param frame
	 */
	protected abstract void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane);

	protected abstract void addPanelJButtons(JPanel contentPane);

	protected abstract void addPanelJLabels(JPanel contentPane);

	/**
	 * NOTE: Calling from children classes violates Template Pattern scheme!
	 */
	protected final void clearJTextFields() {
		for (JTextField f : textFields) {
			f.setText("");
		}
	}

}
