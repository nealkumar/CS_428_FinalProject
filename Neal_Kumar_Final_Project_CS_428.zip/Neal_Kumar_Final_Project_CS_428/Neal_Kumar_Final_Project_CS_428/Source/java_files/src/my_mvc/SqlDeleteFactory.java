package my_mvc;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class SqlDeleteFactory extends SqlFactory {

	@Override
	protected Object performExecution(String tableName, List<String> values, Statement stmt) {
		// TODO Auto-generated method stub
		String sql = "";
		if (tableName.equalsIgnoreCase("TUTORS")) {
			sql = "DELETE from TUTORS where " + tutorsColNames[0] + " = '" + values.get(0) + "' and "
					+ tutorsColNames[1] + " = '" + values.get(1) + "'";
		} else if (tableName.equalsIgnoreCase("TUTOR_CLIENTS")) {
			sql = "DELETE from TUTOR_CLIENTS where " + tutorClientsColNames[0] + " = '" + values.get(0) + "' and "
					+ tutorClientsColNames[1] + " = '" + values.get(1) + "'";
		} else if (tableName.equalsIgnoreCase("TUTOR_PLATFORMS")) {
			sql = "DELETE from TUTOR_PLATFORMS where " + tutorPlatformColNames[0] + " = '" + values.get(0) + "' and "
					+ tutorPlatformColNames[1] + " = '" + values.get(1) + "'";
		} else if (tableName.equalsIgnoreCase("TUTOR_EVENTS")) {
			sql = "DELETE from TUTOR_EVENTS where " + "event_id" + " = '" + values.get(0)
					+ /*
						 * "' and " + tutorPlatformColNames[1] + " = '" + values.get(1) +
						 */ "'";
		}

		try {
			stmt.execute(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Deletion Completed!";
	}

	@Override
	protected Object performExecution(String tableName, String statementSubtype, Object toReturn, Statement stmt,
			boolean returnIdOnly) {
		// TODO Auto-generated method stub
		return null;
	}

}
