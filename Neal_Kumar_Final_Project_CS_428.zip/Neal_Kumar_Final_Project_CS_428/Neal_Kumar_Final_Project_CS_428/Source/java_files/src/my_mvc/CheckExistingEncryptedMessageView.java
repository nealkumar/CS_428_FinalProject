package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CheckExistingEncryptedMessageView extends FormViewTemplate {

	private List<String> messageList;
	private JComboBox<String> encryptedMessageComb;
	private JLabel lblClearText;
	private JLabel lblFrom;

	public CheckExistingEncryptedMessageView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		messageList = new ArrayList<String>();
		messageList = controller.generateAllEncryptedMessagesList(messageList, false);
		encryptedMessageComb = new JComboBox<String>();
		encryptedMessageComb.setBounds(225, 100, 300, 25);
		for (String s : messageList) {
			encryptedMessageComb.addItem(s);
		}
		contentPane.add(encryptedMessageComb);

		JButton btnDecrypt = new JButton("DECRYPT");
		btnDecrypt.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnDecrypt.setBounds(300, 225, 127, 23);
		btnDecrypt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String current = (String) encryptedMessageComb.getSelectedItem();
				List<String> temp = breakUpCurrentSelection(current);
				String encrypted = temp.get(1);// getEncryptedPart(current);
				// System.out.println(encrypted);
				String decrypted = "";
				try {
					decrypted = decrypt(encrypted);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				lblClearText.setText(decrypted);
				lblFrom = setFromLabel(current);
			}

		});
		contentPane.add(btnDecrypt);
	}

	private String decrypt(String encrypted) throws Exception {
		Cipher cipher = Cipher.getInstance("AES");
		Key key = new SecretKeySpec(TutorConstants.SECRET.getBytes(), "AES");
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] decrypted = cipher.doFinal(encrypted.getBytes());
		System.out.println(new String(decrypted));
		return new String(decrypted);
	}

	private JLabel setFromLabel(String current) {
		List<String> temp = breakUpCurrentSelection(current);
		lblFrom.setText("From: " + controller.searchTutorsForFullNameByID(temp.get(0)));
		return lblFrom;
	}

	private List<String> breakUpCurrentSelection(String toBreakUp) {
		List<String> temp = new ArrayList<String>();
		temp = Arrays.asList(toBreakUp.split(",[ ]*"));
		return temp;
	}

	@Override
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblDecrypt = new JLabel("Decrypt Existing Message From A Tutor");
		lblDecrypt.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblDecrypt.setBounds(66, 11, 650, 40);
		contentPane.add(lblDecrypt);

		lblClearText = new JLabel("Clear Text");
		lblClearText.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblClearText.setBounds(100, 350, 500, 30);
		contentPane.add(lblClearText);

		lblFrom = new JLabel("From: ");
		lblFrom.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblFrom.setBounds(450, 350, 500, 30);
		contentPane.add(lblFrom);
	}

}
