package my_mvc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.microsoft.sqlserver.jdbc.SQLServerException;

public class SqlSelectFactory extends SqlFactory {

	@Override
	/**
	 * Searches and returns full names for matching ID values
	 */
	protected Object performExecution(String tableName, List<String> values, Statement stmt) {
		// TODO Auto-generated method stub
		String name = "";
		if (tableName.equalsIgnoreCase("TUTORS")) {

			try {
				String sql = "SELECT * FROM " + tableName + " WHERE tutor_id = '" + values.get(0) + "'";
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					name = rs.getString("tutor_first_name") + " " + rs.getString("tutor_last_name");
				}
			} catch (SQLServerException sqlSEx) {
				sqlSEx.printStackTrace();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else if (tableName.equalsIgnoreCase("TUTOR_CLIENTS")) {
			try {
				String sql = "SELECT * FROM " + tableName + " WHERE tutor_client_id = '" + values.get(0) + "'";
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					name = rs.getString("tutor_client_first_name") + " " + rs.getString("tutor_client_last_name");
				}
			} catch (SQLServerException sqlSEx) {
				sqlSEx.printStackTrace();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else if (tableName.equalsIgnoreCase("TUTOR_PLATFORMS")) {
			try {
				String sql = "SELECT * FROM " + tableName + " WHERE tutor_platform_id = '" + values.get(0) + "'";
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					name = rs.getString("tutor_platform_name") + " - $" + rs.getString("tutor_platform_rate") + "/hr";
				}
			} catch (SQLServerException sqlSEx) {
				sqlSEx.printStackTrace();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return name;
	}

	@Override
	protected Object performExecution(String tableName, String statementSubtype, Object toReturn, Statement stmt,
			boolean returnIdOnly) {
		// TODO Auto-generated method stub
		if (statementSubtype.equalsIgnoreCase("COUNT")) {
			int count = 0;
			// if (tableName.equalsIgnoreCase("TUTORS")) {
			String sql = "SELECT COUNT(*) FROM " + tableName;
			try {
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					count = rs.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// }
			System.out.println("Count Completed!");
			return count;
		} else if (statementSubtype.equalsIgnoreCase("return")) {
			/**
			 * TODO: Re-factor into Strategy Pattern
			 */
			if (tableName.equalsIgnoreCase("TUTORS")) {
				@SuppressWarnings("unchecked")
				List<String> tutorsList = (ArrayList<String>) toReturn;
				tutorsList = new ArrayList<String>();
				try {
					String sql = "SELECT * FROM TUTORS";
					ResultSet rs = stmt.executeQuery(sql);
					while (rs.next()) {
						if (!returnIdOnly) {
							tutorsList.add(rs.getString(tutorsColNames[1]) + ", " + rs.getString(tutorsColNames[0]));
						} else if (returnIdOnly) {
							tutorsList.add(rs.getString("tutor_id"));
						}
					}
					System.out.println("Selection completed!");
				} catch (SQLServerException sqlSEx) {
					sqlSEx.printStackTrace();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				return tutorsList;
			} else if (tableName.equalsIgnoreCase("TUTOR_CLIENTS")) {
				@SuppressWarnings("unchecked")
				List<String> clientsList = (ArrayList<String>) toReturn;
				clientsList = new ArrayList<String>();
				try {
					String sql = "SELECT * FROM " + tableName;
					ResultSet rs = stmt.executeQuery(sql);
					while (rs.next()) {
						if (!returnIdOnly) {
							clientsList.add(rs.getString(tutorClientsColNames[1]) + ", "
									+ rs.getString(tutorClientsColNames[0]));
						} else if (returnIdOnly) {
							clientsList.add(rs.getString("tutor_client_id"));
						}
					}
					System.out.println("Selection completed!");
				} catch (SQLServerException sqlSEx) {
					sqlSEx.printStackTrace();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				return clientsList;
			} else if (tableName.equalsIgnoreCase("TUTOR_PLATFORMS")) {
				@SuppressWarnings("unchecked")
				List<String> platformsList = (ArrayList<String>) toReturn;
				platformsList = new ArrayList<String>();
				try {
					String sql = "SELECT * FROM " + tableName;
					ResultSet rs = stmt.executeQuery(sql);
					while (rs.next()) {
						if (!returnIdOnly) {
							platformsList.add(rs.getString(tutorPlatformColNames[0]) + ", "
									+ rs.getString(tutorPlatformColNames[1]));
						} else if (returnIdOnly) {
							platformsList.add(rs.getString("tutor_platform_id"));
						}
					}
					System.out.println("Selection completed!");
				} catch (SQLServerException sqlSEx) {
					sqlSEx.printStackTrace();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				return platformsList;
			} else if (tableName.equalsIgnoreCase("TUTOR_EVENTS")) {
				@SuppressWarnings("unchecked")
				List<String> platformsList = (ArrayList<String>) toReturn;
				platformsList = new ArrayList<String>();
				try {
					String sql = "SELECT * FROM " + tableName;
					ResultSet rs = stmt.executeQuery(sql);
					while (rs.next()) {
						if (!returnIdOnly) {
							platformsList.add(rs.getString("event_id") + ", " + rs.getString(tutorEventsColNames[0])
									+ ", " + rs.getString(tutorEventsColNames[1]) + ", "
									+ rs.getString(tutorEventsColNames[2]) + ", " + rs.getString(tutorEventsColNames[3])
									+ ", " + rs.getString(tutorEventsColNames[5]) + ", "
									+ rs.getString(tutorEventsColNames[4]) + ", "
									+ rs.getString(tutorEventsColNames[6]));
						} else if (returnIdOnly) {
							platformsList.add(rs.getString("event_id"));
						}
					}
					System.out.println("Selection completed!");
				} catch (SQLServerException sqlSEx) {
					sqlSEx.printStackTrace();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				return platformsList;
			} else if (tableName.equalsIgnoreCase("ENCRYPTED_MESSAGE")) {
				@SuppressWarnings("unchecked")
				List<String> messagesList = (ArrayList<String>) toReturn;
				messagesList = new ArrayList<String>();
				try {
					String sql = "SELECT * FROM " + tableName;
					ResultSet rs = stmt.executeQuery(sql);
					while (rs.next()) {
						messagesList.add(rs.getString("tutor_id") + ", " + rs.getString("message"));
					}
				} catch (SQLServerException sqlSEx) {
					sqlSEx.printStackTrace();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				return messagesList;
			}

			else {
				return "no values to return";
			}
		} // else if (statementSubtype.equalsIgnoreCase("return_full_name")) {
//			String name = "";
//			try {
//				String sql = "SELECT * FROM " + tableName + " WHERE tutor_id = '" + "";
//				ResultSet rs = stmt.executeQuery(sql);
//				while(rs.next()) {
//					
//				}
//			} catch (SQLServerException sqlSEx) {
//				sqlSEx.printStackTrace();
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//			return name;
//		}

		else {
			System.out.println("Error Retrieving Data.");
			return null;
		}

	}

}
