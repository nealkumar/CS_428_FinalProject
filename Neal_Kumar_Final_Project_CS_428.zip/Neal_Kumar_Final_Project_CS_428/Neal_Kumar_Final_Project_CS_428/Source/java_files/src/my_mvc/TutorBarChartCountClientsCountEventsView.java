package my_mvc;

import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class TutorBarChartCountClientsCountEventsView extends TutorBarChartViewTemplate {

	private int clientIDCount = 0, eventIDCount = 0;
	private static final long serialVersionUID = 1L;

	public TutorBarChartCountClientsCountEventsView(String title, TutorControllerTemplate controller) {
		super(title, controller);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		final String totalClients = "Total Clients";
		final String totalEvents = "Total Events";
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		clientIDCount = getController().getClientIDCount();
		eventIDCount = getController().getEventIDCount();

		dataset.addValue(clientIDCount, totalClients, totalClients);
		dataset.addValue(eventIDCount, totalEvents, totalEvents);

		return dataset;
	}

}
