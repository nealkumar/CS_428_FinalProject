package my_mvc;

import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class TutorBarChartCountTutorsCountPlatformsView extends TutorBarChartViewTemplate {

	private int tutorIDCount = 0, platformIDCount = 0;
	private static final long serialVersionUID = -2853382977812869238L;

	public TutorBarChartCountTutorsCountPlatformsView(String title, TutorControllerTemplate controller) {
		super(title, controller);
	}

	@Override
	public CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		final String totalTutors = "Total Tutors";
		final String totalPlatforms = "Total Platforms";
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		platformIDCount = getController().getPlatformsIDCount();
		tutorIDCount = getController().getTutorIDCount();

		System.out.println("PlatformID Count:" + platformIDCount);
		System.out.println("TutorID Count:" + tutorIDCount);

		dataset.addValue(tutorIDCount, totalTutors, totalTutors);
		dataset.addValue(platformIDCount, totalPlatforms, totalPlatforms);

		return dataset;
	}

}
