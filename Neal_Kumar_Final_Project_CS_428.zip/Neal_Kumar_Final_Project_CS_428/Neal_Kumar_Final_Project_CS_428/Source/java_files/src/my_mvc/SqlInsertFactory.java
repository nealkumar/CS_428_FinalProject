package my_mvc;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class SqlInsertFactory extends SqlFactory {

	@Override
	protected Object performExecution(String tableName, List<String> values, Statement stmt) {
		// TODO Auto-generated method stub
		String sql = buildStatement(tableName, values);
		try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Insertion Completed!";
	}

	/**
	 * TODO: re-factor so values aren't hard-coded
	 * 
	 * @param tableName
	 * @param values    - hard-coded in via index (.get() for List)
	 * @return
	 */
	private String buildStatement(String tableName, List<String> values) {
		// TODO Auto-generated method stub
		String sql = "";
		if (tableName.equalsIgnoreCase("TUTORS")) {
			sql = "INSERT into TUTORS values('" + values.get(0) + "','" + values.get(1) + "')";
		} else if (tableName.equalsIgnoreCase("TUTOR_PLATFORMS")) {
			sql = "INSERT into TUTOR_PLATFORMS values('" + values.get(0) + "','" + values.get(1) + "','" + values.get(2)
					+ "')";
		} else if (tableName.equalsIgnoreCase("TUTOR_CLIENTS")) {
			sql = "INSERT into TUTOR_CLIENTS values('" + values.get(0) + "','" + values.get(1) + "','"
					+ Integer.parseInt(values.get(2)) + "')";
		} else if (tableName.equalsIgnoreCase("TUTOR_EVENTS")) {
			sql = "INSERT into TUTOR_EVENTS values('" + values.get(0) + "','" + values.get(1) + "','" + values.get(2)
					+ "','" + values.get(3) + "','" + values.get(4) + "','" + values.get(5) + "','" + values.get(6)
					+ "','" + values.get(7) + "','" + values.get(8) + "')";
		} else if (tableName.equalsIgnoreCase("ENCRYPTED_MESSAGE")) {
			sql = "INSERT into ENCRYPTED_MESSAGE values('" + values.get(0) + "','" + values.get(1) + "')";
		}

		return sql;
	}

	@Override
	protected Object performExecution(String tableName, String statementSubtype, Object toReturn, Statement stmt,
			boolean returnIdOnly) {
		// TODO Auto-generated method stub
		return null;
	}

}
