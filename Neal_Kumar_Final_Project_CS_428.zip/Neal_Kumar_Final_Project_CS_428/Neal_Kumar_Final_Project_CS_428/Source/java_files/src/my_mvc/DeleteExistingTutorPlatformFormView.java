package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DeleteExistingTutorPlatformFormView extends FormViewTemplate {

	private List<String> platformsList;

	public DeleteExistingTutorPlatformFormView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		platformsList = new ArrayList<String>();
		platformsList = controller.generateAllTutorPlatformsList(platformsList, false);

		JComboBox<String> comb = new JComboBox<String>();
		comb.setBounds(175, 100, 200, 25);
		for (String s : platformsList) {
			comb.addItem(s);
		}
		contentPane.add(comb);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(480, 100, 125, 25);
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String currentSelection = (String) comb.getSelectedItem();
				System.out.println(currentSelection);
				List<String> platformNamePlatformRate = new ArrayList<String>();
				platformNamePlatformRate = breakUpStatement(currentSelection, platformNamePlatformRate);
				controller.removeExistingPlatform(platformNamePlatformRate.get(0), platformNamePlatformRate.get(1));
				// TODO - doesn't actually re-query the db to reflect changes... only deletes it
				// from the combo-box... kind of hacky, but can be updated later...
				comb.removeItemAt(comb.getSelectedIndex());
			}

		});
		contentPane.add(btnSubmit);
	}

	@Override
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub

	}

	private List<String> breakUpStatement(String currentSelection, List<String> platformNamePlatformRate) {
		// TODO Auto-generated method stub
		platformNamePlatformRate = Arrays.asList(currentSelection.split(",[ ]*"));
		return platformNamePlatformRate;
	}

}
