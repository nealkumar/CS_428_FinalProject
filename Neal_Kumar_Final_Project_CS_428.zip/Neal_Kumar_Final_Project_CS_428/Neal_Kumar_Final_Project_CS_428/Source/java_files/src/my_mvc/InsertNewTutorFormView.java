package my_mvc;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.jfree.ui.RefineryUtilities;

public class InsertNewTutorFormView {

	private JPanel contentPane;
	private JTextField firstNameTextField;
	private JTextField lastNameTextField;
	private JFrame frame;
	@SuppressWarnings("unused")
	private TutorControllerTemplate controller;

	/**
	 * Create the frame.
	 * 
	 * @param controller
	 */
	public InsertNewTutorFormView(TutorControllerTemplate controller) {
		// super(model, controller);
		this.controller = controller;
		frame = new JFrame("Add New Tutor");
		frame = setup(frame);

//		frame.setBounds(100, 100, 750, 500);
//		contentPane = new JPanel();
//		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//		frame.setContentPane(contentPane);
//		contentPane.setLayout(null);
//		frame.setDefaultCloseOperation(2);
//		frame.setPreferredSize(new Dimension(750, 500));
//		RefineryUtilities.centerFrameOnScreen(frame);
//		frame.pack();
//		frame.setVisible(true);

		JLabel lblAddNewTutor = new JLabel("Add New Tutor Form");
		lblAddNewTutor.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblAddNewTutor.setBounds(193, 11, 333, 58);
		contentPane.add(lblAddNewTutor);

		JLabel lblTutorsFirstName = new JLabel("Tutor's First Name: ");
		lblTutorsFirstName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTutorsFirstName.setBounds(146, 134, 138, 30);
		contentPane.add(lblTutorsFirstName);

		firstNameTextField = new JTextField();
		firstNameTextField.setBounds(294, 140, 232, 20);
		contentPane.add(firstNameTextField);
		firstNameTextField.setColumns(10);

		JLabel lblTutorsLastName = new JLabel("Tutor's Last Name:");
		lblTutorsLastName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTutorsLastName.setBounds(146, 191, 138, 23);
		contentPane.add(lblTutorsLastName);

		lastNameTextField = new JTextField();
		lastNameTextField.setBounds(294, 193, 232, 20);
		contentPane.add(lastNameTextField);
		lastNameTextField.setColumns(10);

		JButton btnClear = new JButton("CLEAR");
		btnClear.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnClear.setBounds(193, 414, 127, 23);
		btnClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearLabels();
			}
		});
		contentPane.add(btnClear);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if (!firstNameTextField.getText().equals(null) && !lastNameTextField.getText().equals(null)) {
					controller.insertNewTutor(firstNameTextField.getText(), lastNameTextField.getText());
					JOptionPane.showMessageDialog(null, "New Tutor Added to the Database!");
					lastNameTextField.setText("");
					firstNameTextField.setText("");
				} else {
					JOptionPane.showMessageDialog(null, "First Name and Last Name fields need info!", "Not Enough Data",
							0);
				}
			}
		});
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(388, 414, 138, 23);
		contentPane.add(btnSubmit);
	}

	private JFrame setup(JFrame frame) {
		frame.setBounds(100, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		frame.setDefaultCloseOperation(2);
		frame.setPreferredSize(new Dimension(750, 500));
		RefineryUtilities.centerFrameOnScreen(frame);
		frame.pack();
		frame.setVisible(true);
		return frame;
	}

	private void clearLabels() {
		lastNameTextField.setText("");
		firstNameTextField.setText("");
	}
}
