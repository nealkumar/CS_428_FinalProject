package my_mvc;

public class TutorDriver428 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		TutorModelTemplate model = new TutorModel();
		TutorControllerTemplate controller = new TutorController(model);
	}

}