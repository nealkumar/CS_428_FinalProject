package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DeleteExistingTutoringEventFormView extends FormViewTemplate {

	private List<String> eventsList;

	public DeleteExistingTutoringEventFormView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		eventsList = new ArrayList<String>();
		eventsList = controller.generateAllTutoringEventsList(eventsList, false);

		JComboBox<String> comb = new JComboBox<String>();
		comb.setBounds(175, 100, 500, 25);
		for (String s : eventsList) {
			comb.addItem(s);
		}
		contentPane.add(comb);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(300, 150, 125, 25);
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String currentSelection = (String) comb.getSelectedItem();
				System.out.println(currentSelection);
				List<String> selectedTutorEvent = new ArrayList<String>();
				selectedTutorEvent = breakUpStatement(currentSelection, selectedTutorEvent);
				controller.removeExistingEvent(selectedTutorEvent.get(0));
				// TODO - doesn't actually re-query the db to reflect changes... only deletes it
				// from the combo-box... kind of hacky, but can be updated later...
				comb.removeItemAt(comb.getSelectedIndex());
			}

		});
		contentPane.add(btnSubmit);
	}

	@Override
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblRemoveExistingTutoringEvent = new JLabel("Remove Existing Tutoring Event");
		lblRemoveExistingTutoringEvent.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblRemoveExistingTutoringEvent.setBounds(175, 15, 500, 50);
		contentPane.add(lblRemoveExistingTutoringEvent);
	}

	private List<String> breakUpStatement(String currentSelection, List<String> platformNamePlatformRate) {
		// TODO Auto-generated method stub
		platformNamePlatformRate = Arrays.asList(currentSelection.split(",[ ]*"));
		return platformNamePlatformRate;
	}

}
