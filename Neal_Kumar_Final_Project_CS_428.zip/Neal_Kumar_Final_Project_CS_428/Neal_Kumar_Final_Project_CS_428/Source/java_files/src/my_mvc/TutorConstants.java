package my_mvc;

import java.util.Observable;

public class TutorConstants extends Observable {

	public static final int PANEL_WIDTH = 750;
	public static final int PANEL_HEIGHT = 250;
	/**
	 * Some SqlFactorys and other classes depend on the column names for each table
	 */
	public static final String[] TUTORS_COL_NAMES = { "tutor_first_name", "tutor_last_name" };
	public static final String[] TUTOR_CLIENTS_COL_NAMES = { "tutor_client_first_name", "tutor_client_last_name",
			"tutor_client_rating" };
	public static final String[] TUTOR_PLATFORM_COL_NAMES = { "tutor_platform_name", "tutor_platform_rate",
			"tutor_platform_description" };
	public static final String[] TUTOR_EVENTS_COL_NAMES = { "tutor_id", "client_id", "platform_id", "tutor_total_mins",
			"day", "month", "year", "estimated_pay_before_tax", "estimated_tax" };

	/**
	 * For the login screen
	 */
	public static String LOGIN_NAME = "";
	public static String PASSWORD = "";

	/**
	 * For the encryption part only
	 */
	public static final byte[] AAD = "iAmRaNdOmIZuR!".getBytes();
	public static final int GCM_NONCE_LENGTH = 12;
	public static final int GCM_TAG_LENGTH = 16;
	public static final String SECRET = "1234567812345678";

}
