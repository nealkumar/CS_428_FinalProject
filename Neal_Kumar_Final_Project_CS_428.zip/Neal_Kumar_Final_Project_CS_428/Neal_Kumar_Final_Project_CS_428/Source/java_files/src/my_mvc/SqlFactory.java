package my_mvc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.List;

import com.microsoft.sqlserver.jdbc.SQLServerException;

/**
 * This Factory class is also a Template for all other Factories
 * 
 * @author Owner
 *
 */
public abstract class SqlFactory {

	protected Statement stmt;
	protected String[] tutorsColNames = TutorConstants.TUTORS_COL_NAMES;
	protected String[] tutorClientsColNames = TutorConstants.TUTOR_CLIENTS_COL_NAMES;
	protected String[] tutorPlatformColNames = TutorConstants.TUTOR_PLATFORM_COL_NAMES;
	protected String[] tutorEventsColNames = TutorConstants.TUTOR_EVENTS_COL_NAMES;
	private static String userName = TutorConstants.LOGIN_NAME;
	private static String password = TutorConstants.PASSWORD;

	/**
	 * @param tableName
	 * @param statementType    - INSERT, DELETE, or SELECT
	 * @param statementSubtype - aggregates such COUNT().. usually for for SELECT
	 *                         statementTypes
	 * @param values           - values to be retrieved
	 * @return - object (abstracted) back to the Controller (which then passes the
	 *         values back to the respective class (so far in this implementation
	 *         it's just a String indicating wether the operation has been completed
	 *         successfully or not... see TutorModelTemplate.java
	 */
	public static final Object executeStatementWithReturn(String tableName, String statementType,
			String statementSubtype, List<String> values, boolean returnIdOnly) {
		Object obj = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection connection = DriverManager
					.getConnection("jdbc:sqlserver://nealkdbserver.database.windows.net:1433;database=tutor;user="
							+ userName + "@nealkdbserver;password=" + password
							+ ";encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

			System.out.println("Connection Established");
			System.out.println("Database type: " + connection.getMetaData().getDatabaseProductName() + "\n User: "
					+ connection.getMetaData().getUserName());
			Statement stmt;
			stmt = connection.createStatement();
			obj = executeStatement(tableName, statementType, statementSubtype, values, obj, stmt, returnIdOnly);
			connection.close();
		} catch (SQLServerException sqlSEx) {
			sqlSEx.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return obj;
	}

	private final static Object executeStatement(String tableName, String statementType, String statementSubtype,
			List<String> values, Object toReturn, Statement stmt, boolean returnIdOnly) {
		if (statementType.equalsIgnoreCase("INSERT")) {
			toReturn = new SqlInsertFactory().performExecution(tableName, values, stmt);
		} else if (statementType.equalsIgnoreCase("SELECT")) {
			if (!statementSubtype.equals("return_special")) {
				toReturn = new SqlSelectFactory().performExecution(tableName, statementSubtype, toReturn, stmt,
						returnIdOnly);
			} else if (statementSubtype.equals("return_special")) {
				toReturn = new SqlSelectFactory().performExecution(tableName, values, stmt);
			}
		} else if (statementType.equalsIgnoreCase("DELETE")) {
			toReturn = new SqlDeleteFactory().performExecution(tableName, values, stmt);
		}
		return toReturn;
	}

	protected abstract Object performExecution(String tableName, List<String> values, Statement stmt);

	protected abstract Object performExecution(String tableName, String statementSubtype, Object toReturn,
			Statement stmt, boolean returnIdOnly);

}
