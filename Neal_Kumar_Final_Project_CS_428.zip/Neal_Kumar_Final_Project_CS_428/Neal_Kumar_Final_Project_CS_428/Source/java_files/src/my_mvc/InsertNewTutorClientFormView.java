package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertNewTutorClientFormView extends FormViewTemplate {

	private TutorControllerTemplate controller;
	private JTextField firstNameTextField;
	private JTextField lastNameTextField;
	private JTextField ratingTextField;

	public InsertNewTutorClientFormView(TutorControllerTemplate controller, int[] bounds, String formName) {
		super(controller, bounds, formName);
		this.controller = controller;
	}

	@Override
	/**
	 * This needs to be refactored
	 */
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblAddNewClient = new JLabel("Add New Client Form");
		lblAddNewClient.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblAddNewClient.setBounds(193, 11, 333, 30);
		contentPane.add(lblAddNewClient);

		JLabel lblClientsFirstName = new JLabel("Client's First Name: ");
		lblClientsFirstName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblClientsFirstName.setBounds(146, 134, 138, 30);
		contentPane.add(lblClientsFirstName);

		JLabel lblTutorsLastName = new JLabel("Tutor's Last Name:");
		lblTutorsLastName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTutorsLastName.setBounds(146, 191, 138, 23);
		contentPane.add(lblTutorsLastName);

		JLabel lblClientRating = new JLabel("Client's Rating:");
		lblClientRating.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblClientRating.setBounds(146, 248, 138, 23);
		contentPane.add(lblClientRating);
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub
		firstNameTextField = new JTextField();
		firstNameTextField.setBounds(294, 140, 232, 20);
		contentPane.add(firstNameTextField);
		firstNameTextField.setColumns(10);
		textFields.add(firstNameTextField);

		lastNameTextField = new JTextField();
		lastNameTextField.setBounds(294, 193, 232, 20);
		contentPane.add(lastNameTextField);
		lastNameTextField.setColumns(10);
		textFields.add(lastNameTextField);

		ratingTextField = new JTextField();
		ratingTextField.setBounds(294, 256, 232, 20);
		contentPane.add(ratingTextField);
		ratingTextField.setColumns(10);
		textFields.add(ratingTextField);
	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		JButton btnClear = new JButton("CLEAR");
		btnClear.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnClear.setBounds(193, 414, 127, 23);
		btnClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearJTextFields(); // NOTE: THIS IS A VIOLATION OF THE TEMPLATE PATTERN!!
			}
		});
		contentPane.add(btnClear);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(393, 414, 127, 23);
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!firstNameTextField.getText().equals(null) && !lastNameTextField.getText().equals(null)
						&& !ratingTextField.getText().equals(null)) {
					// TODO Auto-generated method stub
					controller.insertNewClient(firstNameTextField.getText(), lastNameTextField.getText(),
							ratingTextField.getText());
					JOptionPane.showMessageDialog(null, "New Client Added to the Database!");
					clearJTextFields(); // NOTE: THIS IS A VIOLATION OF THE TEMPLATE PATTERN!!
				} else {
					JOptionPane.showMessageDialog(null,
							"First Name, Last Name, and Rating fields cannot be blank! Please Try again.",
							"Not Enough Data", 0);
				}
			}
		});
		contentPane.add(btnSubmit);

	}

}
