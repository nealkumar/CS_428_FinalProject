package my_mvc;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.RefineryUtilities;

public abstract class TutorBarChartViewTemplate extends JFrame implements TutorChart {

	private TutorControllerTemplate controller;
	private static final long serialVersionUID = 1L;

	public TutorBarChartViewTemplate(String title, TutorControllerTemplate controller) {
		super(title);
		this.setController(controller);
		JFreeChart barChart = ChartFactory.createBarChart(title, "ID Type", "Total Count", createDataset());
		ChartPanel chartPanel = new ChartPanel(barChart);
		this.setContentPane(chartPanel);
		this.setDefaultCloseOperation(2);
		this.pack();
		RefineryUtilities.positionFrameRandomly(this);
		this.setVisible(true);
	}

	public TutorControllerTemplate getController() {
		return controller;
	}

	public void setController(TutorControllerTemplate controller) {
		this.controller = controller;
	}

}
