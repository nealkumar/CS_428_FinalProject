package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * FormViewTemplate is my Template Method Pattern to create each Form View
 * 
 * @author nealk
 *
 */
public class ServerLoginView extends FormViewTemplate {

	JTextField userNameTextField;
	JPasswordField passwordTextField; // muddles the text from plain sight... helped when I was demoing the project
										// for the 476 class
	boolean canConnect;

	public ServerLoginView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
		this.canConnect = false;
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub
		userNameTextField = new JTextField();
		userNameTextField.setBounds(294, 140, 232, 20);
		contentPane.add(userNameTextField);
		userNameTextField.setColumns(10);
		textFields.add(userNameTextField);

		passwordTextField = new JPasswordField();
		passwordTextField.setBounds(294, 193, 232, 20);
		contentPane.add(passwordTextField);
		passwordTextField.setColumns(10);
		textFields.add(passwordTextField);
	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		JButton btnClear = new JButton("CLEAR");
		btnClear.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnClear.setBounds(193, 350, 127, 23);
		btnClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearJTextFields(); // NOTE: THIS IS A VIOLATION OF THE TEMPLATE PATTERN!!
			}
		});
		contentPane.add(btnClear);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(393, 350, 127, 23);
		btnSubmit.addActionListener(new ActionListener() { // when button is clicked
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> { // new thread allows for button action to free up
					try {
						canConnect = checkIfValidCredentials(userNameTextField.getText(),
								new String(passwordTextField.getPassword()));
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}).start();

				if (canConnect) { // if connection is good, sets TutorConstants.USER_NAME and PASSWORD to the
									// values
					controller.setDbUserNameAndPassword(userNameTextField.getText(),
							new String(passwordTextField.getPassword()));
					clearJTextFields(); // NOTE: THIS IS A VIOLATION OF THE TEMPLATE PATTERN!!
					JOptionPane.showMessageDialog(null, "Connection Success! You can safely close this window.",
							"Connection Success!", 0);
					// closes the window
					frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
				} else {
					JOptionPane.showMessageDialog(null, "Connection Failed. Please try again.", "Connection Failed", 0);
					clearJTextFields();
					return;
				}
			}

		});
		contentPane.add(btnSubmit);
	}

	/**
	 * Verifies whether provided credentials are valid by attempting to login to the
	 * DB
	 * 
	 * @param userName
	 * @param password
	 * @return
	 * @throws ClassNotFoundException - dumb
	 */
	private boolean checkIfValidCredentials(String userName, String password) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection connection = DriverManager
					.getConnection("jdbc:sqlserver://nealkdbserver.database.windows.net:1433;database=tutor;user="
							+ userName + "@nealkdbserver;password=" + password
							+ ";encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");
			if (connection.isValid(5)) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblServerLogin = new JLabel("Provide Server Login Credentials");
		lblServerLogin.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblServerLogin.setBounds(125, 11, 500, 40);
		contentPane.add(lblServerLogin);

		JLabel lblUserName = new JLabel("Username: ");
		lblUserName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblUserName.setBounds(146, 134, 138, 30);
		contentPane.add(lblUserName);

		JLabel lblPassword = new JLabel("Password: ");
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblPassword.setBounds(150, 191, 138, 30);
		contentPane.add(lblPassword);
	}

}
