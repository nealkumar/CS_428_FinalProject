package my_mvc;

import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class TutorBarChartCountTutorsCountEventsView extends TutorBarChartViewTemplate {

	private int tutorIDCount = 0, eventIDCount = 0;
	private static final long serialVersionUID = 1L;

	public TutorBarChartCountTutorsCountEventsView(String title, TutorControllerTemplate controller) {
		super(title, controller);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		final String totalTutors = "Total Tutors";
		final String totalEvents = "Total Events";
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		tutorIDCount = getController().getTutorIDCount();
		eventIDCount = getController().getEventIDCount();

		dataset.addValue(tutorIDCount, totalTutors, totalTutors);
		dataset.addValue(eventIDCount, totalEvents, totalEvents);

		return dataset;
	}

}
