package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertNewTutoringEventFormView extends FormViewTemplate {

	private List<String> tutorIdList;
	private List<String> clientIdList;
	private List<String> platformIdList;

	private JTextField totalMins;
	private JTextField month;
	private JTextField day;
	private JTextField year;
	private JTextField estimatedPay;
	private JTextField estimatedTax;

	private JLabel lblTutorName;
	private JLabel lblClientName;
	private JLabel lblPlatformName;

	private JComboBox<String> tutorComb;
	private JComboBox<String> clientComb;
	private JComboBox<String> platformComb;

	private int height;
	private JTextField[] textFieldArr;

	public InsertNewTutoringEventFormView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
		height = 0;
	}

	@Override
	/**
	 * TODO: Can easily be recursed!!
	 */
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub
		textFields.add(totalMins);
		textFields.add(month);
		textFields.add(day);
		textFields.add(year);
		textFields.add(estimatedPay);
		textFields.add(estimatedTax);
		textFieldArr = new JTextField[6];
		implementTextFields(contentPane, height);
	}

	/**
	 * Recursive function to add text fields on form
	 * 
	 * @param contentPane
	 * @param index
	 */
	private void implementTextFields(JPanel contentPane, int index) {
		JTextField f = textFields.get(index);
		f = new JTextField();
		f.setBounds(500, ((index * 50) + 281), 300, 20);
		contentPane.add(f);
		f.setColumns(10);
		textFields.add(index, f);
		textFieldArr[index] = f;
		index += 1;
		if (index == textFieldArr.length) {
			return;
		} else {
			implementTextFields(contentPane, index);
		}
	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		tutorIdList = new ArrayList<String>();
		tutorIdList = controller.generateAllTutorsList(tutorIdList, true);
		/* JComboBox<String> */ tutorComb = new JComboBox<String>();
		tutorComb.setBounds(100, 150, 150, 25);
		for (String s : tutorIdList) {
			tutorComb.addItem(s);
		}
		tutorComb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				updateTutorName();
			}
		});
		updateTutorName();
		contentPane.add(tutorComb);

		clientIdList = new ArrayList<String>();
		clientIdList = controller.generateAllTutorClientsList(clientIdList, true);
		clientComb = new JComboBox<String>();
		clientComb.setBounds(400, 150, 150, 25);
		for (String s : clientIdList) {
			clientComb.addItem(s);
		}
		clientComb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				updateClientName();
			}
		});
		updateClientName();
		contentPane.add(clientComb);

		platformIdList = new ArrayList<String>();
		platformIdList = controller.generateAllTutorPlatformsList(platformIdList, true);
		platformComb = new JComboBox<String>();
		platformComb.setBounds(700, 150, 150, 25);
		for (String s : platformIdList) {
			platformComb.addItem(s);
		}
		platformComb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				updatePlatformName();
			}
		});
		updatePlatformName();
		contentPane.add(platformComb);

		JButton btnClear = new JButton("CLEAR");
		btnClear.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnClear.setBounds(300, 600, 127, 23);
		btnClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearTextFields();
			}
		});
		contentPane.add(btnClear);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(600, 600, 127, 23);
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// if (!platformNameTextField.getText().equals(null) &&
				// !platformRateTextField.getText().equals(null)
				// && !platformDescriptionTextField.getText().equals(null)) {
				// TODO Auto-generated method stub
				String tutorID = (String) tutorComb.getSelectedItem();
				String clientID = (String) clientComb.getSelectedItem();
				String platformID = (String) platformComb.getSelectedItem();
				controller.insertNewEvent(tutorID, clientID, platformID, textFieldArr[0].getText(),
						textFieldArr[2].getText(), textFieldArr[1].getText(), textFieldArr[3].getText(),
						textFieldArr[4].getText(), textFieldArr[5].getText());
				JOptionPane.showMessageDialog(null, "New Tutoring Event Added to the Database!");
//				for (int index = 0; index < textFieldArr.length; index++) {
//					textFieldArr[index].setText("");
//				}
				clearTextFields();
				// } else {
//				JOptionPane.showMessageDialog(null,
//						"Platform Name, Platform Rate (int), and Platform Description cannot be blank! Please Try again.",
//						"Not Enough Data", 0);
				// }
			}
		});
		contentPane.add(btnSubmit);
	}

	private void clearTextFields() {
		for (int index = 0; index < textFieldArr.length; index++) {
			textFieldArr[index].setText("");
		}
	}

	@Override
	/**
	 * Can't really be automated because each label's width is different...
	 */
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblAddNewEvent = new JLabel("Add New Tutoring Event Form");
		lblAddNewEvent.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblAddNewEvent.setBounds(285, 11, 600, 38);
		contentPane.add(lblAddNewEvent);

		JLabel lblTutorIDNumber = new JLabel("Tutor ID Number:");
		lblTutorIDNumber.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblTutorIDNumber.setBounds(100, 100, 200, 30);
		contentPane.add(lblTutorIDNumber);

		lblTutorName = new JLabel("Tutor Name");
		lblTutorName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblTutorName.setBounds(110, 200, 200, 30);
		contentPane.add(lblTutorName);

		JLabel lblClientIDNumber = new JLabel("Client ID Number:");
		lblClientIDNumber.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblClientIDNumber.setBounds(400, 100, 200, 30);
		contentPane.add(lblClientIDNumber);

		lblClientName = new JLabel("Client Name");
		lblClientName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblClientName.setBounds(410, 200, 200, 30);
		contentPane.add(lblClientName);

		JLabel lblPlatformIDNumber = new JLabel("Platform ID Number:");
		lblPlatformIDNumber.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblPlatformIDNumber.setBounds(695, 100, 200, 30);
		contentPane.add(lblPlatformIDNumber);

		lblPlatformName = new JLabel("Platform Name");
		lblPlatformName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblPlatformName.setBounds(715, 200, 200, 30);
		contentPane.add(lblPlatformName);

		JLabel lblTotalTime = new JLabel("Total Tutoring Time (E.g. 108.99):");
		lblTotalTime.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblTotalTime.setBounds(175, 275, 300, 30);
		contentPane.add(lblTotalTime);

		JLabel lblMonth = new JLabel("Month (E.g. 3):");
		lblMonth.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblMonth.setBounds(320, 325, 300, 30);
		contentPane.add(lblMonth);

		JLabel lblDay = new JLabel("Day (E.g. 21):");
		lblDay.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblDay.setBounds(332, 375, 300, 30);
		contentPane.add(lblDay);

		JLabel lblYear = new JLabel("Year (E.g. 2019):");
		lblYear.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblYear.setBounds(310, 425, 300, 30);
		contentPane.add(lblYear);

		JLabel lblEstimatedPay = new JLabel("Estimated Pay Before Tax (E.g. 99.995):");
		lblEstimatedPay.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblEstimatedPay.setBounds(131, 475, 400, 30);
		contentPane.add(lblEstimatedPay);

		JLabel lblEstimatedTax = new JLabel("Estimated Tax (E.g. 3.012 - Enter 99999 for unknown vals):");
		lblEstimatedTax.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblEstimatedTax.setBounds(46, 525, 500, 30);
		contentPane.add(lblEstimatedTax);
	}

	private void updateTutorName() {
		// TODO Auto-generated method stub
		String selectedItem = (String) tutorComb.getSelectedItem();
		String tutorName = controller.searchTutorsForFullNameByID(selectedItem);
		lblTutorName.setText(tutorName);
	}

	private void updateClientName() {
		// TODO Auto-generated method stub
		String selectedItem = (String) clientComb.getSelectedItem();
		String tutorName = controller.searchTutorClientsForFullNameByID(selectedItem);
		lblClientName.setText(tutorName);
	}

	private void updatePlatformName() {
		// TODO Auto-generated method stub
		String selectedItem = (String) platformComb.getSelectedItem();
		String tutorName = controller.searchTutorPlatformsForFullNameByID(selectedItem);
		lblPlatformName.setText(tutorName);
	}

}
