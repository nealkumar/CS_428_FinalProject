package my_mvc;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * FormViewTemplate is my Template Method Pattern to create each Form View
 * 
 * @author nealk
 *
 */
public class InsertNewEncryptedMessageView extends FormViewTemplate {

	private JTextField messageTextField;

	private JComboBox<String> tutorComb;
	private List<String> tutorIdList;
	private JLabel lblTutorName;

	public InsertNewEncryptedMessageView(TutorControllerTemplate controller, int[] bounds, String frameName) {
		super(controller, bounds, frameName);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void addPanelJTextFields(List<JTextField> textFields, JPanel contentPane) {
		// TODO Auto-generated method stub
		messageTextField = new JTextField();
		messageTextField.setBounds(300, 205, 232, 20);
		contentPane.add(messageTextField);
		messageTextField.setColumns(10);
		textFields.add(messageTextField);
	}

	@Override
	protected void addPanelJButtons(JPanel contentPane) {
		// TODO Auto-generated method stub
		tutorIdList = new ArrayList<String>();
		tutorIdList = controller.generateAllTutorsList(tutorIdList, true);
		tutorComb = new JComboBox<String>();
		tutorComb.setBounds(140, 135, 150, 25);
		for (String s : tutorIdList) {
			tutorComb.addItem(s);
		}
		tutorComb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				updateTutorName();
			}
		});
		updateTutorName();
		contentPane.add(tutorComb);

		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSubmit.setBounds(300, 350, 127, 23);
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String msg = messageTextField.getText();
				try {
					msg = encryptMessage(msg); // encrypts message
				} catch (Exception ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
				// System.out.println("Encrypted Message: " + msg);
				String selectedTutorID = (String) tutorComb.getSelectedItem();
				controller.insertNewEncryptedMessage(selectedTutorID, msg);
				JOptionPane.showMessageDialog(null, "New Encrypted Message Added to the Database!");
				clearJTextFields(); // NOTE: THIS IS A VIOLATION OF THE TEMPLATE PATTERN!!
			}
		});
		contentPane.add(btnSubmit);
	}

	@Override
	protected void addPanelJLabels(JPanel contentPane) {
		// TODO Auto-generated method stub
		JLabel lblAddNewClient = new JLabel("Add New Encrypted Message Form");
		lblAddNewClient.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblAddNewClient.setBounds(110, 11, 550, 40);
		contentPane.add(lblAddNewClient);

		JLabel lblEncryptedMessage = new JLabel("Encrypted Message: ");
		lblEncryptedMessage.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblEncryptedMessage.setBounds(146, 200, 165, 30);
		contentPane.add(lblEncryptedMessage);

		lblTutorName = new JLabel("Tutor Name");
		lblTutorName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTutorName.setBounds(350, 130, 200, 30);
		contentPane.add(lblTutorName);
	}

	/**
	 * So many Exceptions...
	 * 
	 * Simple encryption process based upon seed in TutorConstants.SECRET
	 * 
	 * @param msg
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private String encryptMessage(String msg)
			throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		Cipher cipher = Cipher.getInstance("AES"); // Returns a Cipher object
		Key key = new SecretKeySpec(TutorConstants.SECRET.getBytes(), "AES"); // creates new AES key based on seed
		cipher.init(Cipher.ENCRYPT_MODE, key); // initializes the cipher
		byte[] encryptedData = cipher.doFinal(msg.getBytes()); // encryptes the data into a byte array

		return new String(encryptedData); // returns as a String
	}

	private void updateTutorName() {
		// TODO Auto-generated method stub
		String selectedItem = (String) tutorComb.getSelectedItem();
		String tutorName = controller.searchTutorsForFullNameByID(selectedItem);
		lblTutorName.setText(tutorName);
	}

}
