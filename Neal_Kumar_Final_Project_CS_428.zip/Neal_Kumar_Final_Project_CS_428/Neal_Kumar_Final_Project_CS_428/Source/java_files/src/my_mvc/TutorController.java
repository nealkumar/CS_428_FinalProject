package my_mvc;

import java.util.List;

import javax.swing.SwingUtilities;

/**
 * Concrete Controller is mostly for thread control.
 * 
 * @author Owner
 *
 */
public class TutorController extends TutorControllerTemplate {

	public TutorController(TutorModelTemplate model) {
		// TODO Auto-generated constructor stub
		super(model);
	}

	@Override
	public void startBarChartDemo() {
		// TODO Auto-generated method stub
		model.setApplicationTitle("My Application Title");
		model.setChartTitle("Chart Title");

		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.startBarChartDemo(model.getApplicationTitle(), model.getChartTitle());
			}
		});
	}

	@Override
	protected void addNewTutorFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		/**
		 * Puts it in the AWT-Event dispatching thread... not sure if this is good or
		 * bad (proper Java says that all Swing Events should be on the same thread).
		 * This I believe this allows for Concurrent Modification?
		 */
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewInsertNewTutorFormView(controller);
			}
		});
	}

	@Override
	protected void removeExistingTutorFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewDeleteExistingTutorFormView(controller);
			}
		});
	}

	@Override
	/**
	 * TODO: These should be put into factories...
	 */
	protected void addNewClientFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewInsertNewTutorClientFormView(controller);
			}
		});
	}

	@Override
	protected void removeExistingTutorClientFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewDeleteExistingTutorClientFormView(controller);
			}
		});
	}

	@Override
	protected void addNewPlatformFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewInsertNewTutorPlatformFormView(controller);
			}
		});
	}

	@Override
	protected void removeExistingPlatformFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewDeleteExistingTutorPlatformFormView(controller);
			}
		});
	}

	@Override
	protected void addNewEventFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewInsertNewTutorEventFormView(controller);
			}
		});
	}

	@Override
	protected void removeExistingEventFormView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewDeleteExistingTutorEventFormView(controller);
			}
		});
	}

	@Override
	protected void newStopwatchMiniView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		model.newStopwatchMiniView(controller);
	}

	protected void newViewExistingEncryptedMessageView(TutorControllerTemplate controller) {
		model.viewExisingEncryptedMessageView(controller);
	}

	@Override
	protected List<String> generateAllTutorsList(List<String> tutorsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		tutorsList = model.generateTheTutorsList(tutorsList, idNumberOnly);
		return tutorsList;
	}

	@Override
	protected List<String> generateAllTutorClientsList(List<String> clientsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		clientsList = model.generateTheClientsList(clientsList, idNumberOnly);
		return clientsList;
	}

	@Override
	public List<String> generateAllTutorPlatformsList(List<String> platformsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		platformsList = model.generateThePlatformsList(platformsList, idNumberOnly);
		return platformsList;
	}

	@Override
	protected List<String> generateAllTutoringEventsList(List<String> eventsList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		eventsList = model.generateTheEventsList(eventsList, idNumberOnly);
		return eventsList;
	}

	@Override
	protected List<String> generateAllEncryptedMessagesList(List<String> messageList, boolean idNumberOnly) {
		// TODO Auto-generated method stub
		messageList = model.generateTheMessagesList(messageList, false);
		return messageList;
	}

	@Override
	protected void newCountClientsCountTutorsBarCartView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {

			/**
			 * Puts it in the AWT-Event dispatching thread... not sure if this is good or
			 * bad (proper Java says that all Swing Events should be on the same thread).
			 * This I believe this allows for Concurrent Modification?
			 */
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createBarChartCountClientsCountTutors(controller);
			}

		});
	}

	@Override
	protected void newCountTutorsCountPlatformsBarCartView(TutorControllerTemplate controller) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createBarChartCountTutorsCountPlatforms(controller);
			}
		});
	}

	@Override
	protected void newCountTutorsCountEventsBarChartView(TutorControllerTemplate tutorControllerTemplate) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createBarChartCountTutorsCountEvents(tutorControllerTemplate);
			}
		});
	}

	@Override
	protected void newCountClientsCountPlatformsBarChartView(TutorControllerTemplate tutorControllerTemplate) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createBarChartCountClientsCountPlatforms(tutorControllerTemplate);
			}
		});
	}

	@Override
	protected void newCountClientsCountEventsBarChartView(TutorControllerTemplate tutorControllerTemplate) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createBarChartCountClientsCountEvents(tutorControllerTemplate);
			}
		});
	}

	@Override
	protected void newCountPlatformsCountEventsBarChartView(TutorControllerTemplate tutorControllerTemplate) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createBarChartCountPlatformsCountEvents(tutorControllerTemplate);
			}
		});
	}

	@Override
	protected void newCountAllBarChartView(TutorControllerTemplate tutorControllerTemplate) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createBarChartCountAll(tutorControllerTemplate);
			}
		});
	}

	@Override
	protected void newAddEncryptedMessageView(TutorControllerTemplate tutorControllerTemplate) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewAddEncryptedMessageView(tutorControllerTemplate);
			}
		});
	}

	@Override
	protected void newAddServerLoginView(TutorControllerTemplate tutorControllerTemplate) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.createNewServerLoginView(tutorControllerTemplate);
			}
		});
	}

}
