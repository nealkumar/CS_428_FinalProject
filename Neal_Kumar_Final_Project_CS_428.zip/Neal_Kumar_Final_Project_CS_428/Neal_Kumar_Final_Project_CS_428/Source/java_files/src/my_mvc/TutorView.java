package my_mvc;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TutorView implements ActionListener, Observer {

	TutorModelTemplate model;
	TutorControllerTemplate controller;

	JFrame controlFrame;
	JPanel controlPanel;
	JButton countdownButton;
	JMenuBar menuBar;
	JMenu chartMenu;
	JMenu barChartMenu;
	JMenu pieChartMenu;
	JMenu eventMenu;
	JMenu tutorMenu;
	JMenu clientMenu;
	JMenu platformMenu;
	JMenu timerMenu;
	JMenu stopwatchMenu;
	JMenu encryptedStorage;
	JMenuItem testBarChartMenuItem;
	JMenuItem barChartClientIDCountTutorIDCountMenuItem;
	JMenuItem barChartTutorIDCountPlatformIDCountMenuItem;
	JMenuItem barChartTutorIDCountEventIDCountMenuItem;
	JMenuItem barChartClientIDCountPlatformIDCountMenuItem;
	JMenuItem barChartClientIDCountEventIDCountMenuItem;
	JMenuItem barChartPlatformIDCountEventIDCountMenuItem;
	JMenuItem barChartClientIDCountEventIDCountPlatformIDCountTutorIDCount;
	JMenuItem testPieChartMenuItem;
	JMenuItem newTutorEventMenuItem;
	JMenuItem removeTutorEventMenuItem;
	JMenuItem newClientMenuItem;
	JMenuItem checkIfExisitingClientMenuItem;
	JMenuItem removeClientMenuItem;
	JMenuItem newTutorMenuItem;
	JMenuItem checkIfExisitingTutorMenuItem;
	JMenuItem removeTutorMenuItem;
	JMenuItem newTutorPlatformMenuItem;
	JMenuItem removeTutorPlatformMenuItem;
	JMenuItem stopwatchMini60MinutesMenuItem;
	JMenuItem encryptedStorageAddTestMenuItem;
	JMenuItem encryptedStorageViewTestMenuItem;
	JMenuItem encryptedStorageRemoveTestMenuItem;

	JLabel calendarMonthJLabel = new JLabel();
	Calendar calendar = new GregorianCalendar();
	DefaultTableModel calendarTable;

	// import constants
	private int panelWidth = TutorConstants.PANEL_WIDTH;
	private int panelHeight = TutorConstants.PANEL_HEIGHT;

	public TutorView(TutorModelTemplate model, TutorControllerTemplate controller) {

		this.model = model;
		this.controller = controller;

		// Creates Login Form
		controller.newAddNewServerLoginView();

		model.addObserver(this);
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if (((String) arg).equals("new tutor")) {
			System.out.println("View Says: " + (String) arg);
		}
	}

	public void createView() {
		controlPanel = new JPanel();
		controlFrame = new JFrame("Main Control");
		controlFrame.setDefaultCloseOperation(3);
		controlFrame.setPreferredSize(new Dimension(panelWidth, panelHeight));

		controlFrame.getContentPane().add(controlPanel, BorderLayout.CENTER);

		controlFrame.pack();
		controlFrame.setVisible(true);

		initCalendar();
	}

	public void createControls() {
		JFrame.setDefaultLookAndFeelDecorated(true);

		menuBar = new JMenuBar();
		chartMenu = new JMenu("View Charts");
		barChartMenu = new JMenu("Bar Chart");
		pieChartMenu = new JMenu("Pie Chart");
		eventMenu = new JMenu("Event Menu");
		tutorMenu = new JMenu("Tutor Menu");
		clientMenu = new JMenu("Client Menu");
		platformMenu = new JMenu("Platform Menu");
		timerMenu = new JMenu("Timer Menu");
		stopwatchMenu = new JMenu("Stopwatches");
		encryptedStorage = new JMenu("Encrypted Storage");

		testBarChartMenuItem = new JMenuItem("Bar Chart Demo");
		barChartClientIDCountTutorIDCountMenuItem = new JMenuItem("Total Clients and Tutors");
		barChartTutorIDCountPlatformIDCountMenuItem = new JMenuItem("Total Tutors and Total Platforms");
		barChartTutorIDCountEventIDCountMenuItem = new JMenuItem("Total Tutors and Total Tutoring Events");
		barChartClientIDCountPlatformIDCountMenuItem = new JMenuItem("Total Clients and Total Platforms");
		barChartClientIDCountEventIDCountMenuItem = new JMenuItem("Total Clients and Total Tutoring Events");
		barChartPlatformIDCountEventIDCountMenuItem = new JMenuItem("Total Platforms and Total Events");
		barChartClientIDCountEventIDCountPlatformIDCountTutorIDCount = new JMenuItem(
				"Total Clients, Total Events, Total Platforms, and Total Tutors");
		testPieChartMenuItem = new JMenuItem("Pie Chart Demo");
		newTutorEventMenuItem = new JMenuItem("New Tutoring Event");
		removeTutorEventMenuItem = new JMenuItem("Remove Tutoring Event");
		newClientMenuItem = new JMenuItem("Add New Client");
		removeClientMenuItem = new JMenuItem("Remove Existing Client");
		checkIfExisitingClientMenuItem = new JMenuItem("Check For Exising Client");
		newTutorMenuItem = new JMenuItem("Add New Tutor");
		checkIfExisitingTutorMenuItem = new JMenuItem("Check For Existing Tutor");
		removeTutorMenuItem = new JMenuItem("Remove Existing Tutor");
		newTutorPlatformMenuItem = new JMenuItem("Add New Tutoring Platform");
		removeTutorPlatformMenuItem = new JMenuItem("Remove Existing Tutor Platform");
		stopwatchMini60MinutesMenuItem = new JMenuItem("Mini 60 Minute Stopwatch");
		encryptedStorageAddTestMenuItem = new JMenuItem("Leave An Encrypted Note for Other Tutors");
		encryptedStorageViewTestMenuItem = new JMenuItem("View An Encrypted Note From You/Another Tutor");
		encryptedStorageRemoveTestMenuItem = new JMenuItem("Remove An Encrypted Note for Other Tutors");

		// barChartMenu.add(testBarChartMenuItem);
		barChartMenu.add(barChartClientIDCountTutorIDCountMenuItem);
		barChartMenu.add(barChartTutorIDCountPlatformIDCountMenuItem);
		barChartMenu.add(barChartTutorIDCountEventIDCountMenuItem);
		barChartMenu.add(barChartClientIDCountPlatformIDCountMenuItem);
		barChartMenu.add(barChartClientIDCountEventIDCountMenuItem);
		barChartMenu.add(barChartPlatformIDCountEventIDCountMenuItem);
		barChartMenu.add(barChartClientIDCountEventIDCountPlatformIDCountTutorIDCount);
		pieChartMenu.add(testPieChartMenuItem);

		chartMenu.add(barChartMenu);
		chartMenu.add(pieChartMenu);
		eventMenu.add(newTutorEventMenuItem);
		eventMenu.add(removeTutorEventMenuItem);
		clientMenu.add(newClientMenuItem);
		clientMenu.add(removeClientMenuItem);
		tutorMenu.add(newTutorMenuItem);
		tutorMenu.add(removeTutorMenuItem);
		platformMenu.add(newTutorPlatformMenuItem);
		platformMenu.add(removeTutorPlatformMenuItem);

		stopwatchMenu.add(stopwatchMini60MinutesMenuItem);
		timerMenu.add(stopwatchMenu);

		encryptedStorage.add(encryptedStorageAddTestMenuItem);
		encryptedStorage.add(encryptedStorageViewTestMenuItem);
		// encryptedStorage.add(encryptedStorageRemoveTestMenuItem);

		testBarChartMenuItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				controller.startBarChartDemo();
			}

		});

		/**
		 * Snippet sent to Dr. Palmer... Q1. How are threads handled by the GC? What
		 * about GC Pause time? Q2. Do I need to explicity set this as a non-Daemon?
		 */
		barChartClientIDCountTutorIDCountMenuItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (controller) {
					controller.addNewBarChartView("CountClientsCountTutors");
					// }
				})/* .setDaemon(false) */.start();
			}

		});

		barChartTutorIDCountEventIDCountMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (controller) {
					controller.addNewBarChartView("CountTutorsCountEvents");
					// }
				}).start();
			}
		});

		barChartTutorIDCountPlatformIDCountMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (controller) {
					controller.addNewBarChartView("CountTutorsCountPlatforms");
					// }
				}).start();
			}
		});

		barChartClientIDCountPlatformIDCountMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (controller) {
					controller.addNewBarChartView("CountClientsCountPlatforms");
					// }
				}).start();
			}
		});

		barChartClientIDCountEventIDCountMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (controller) {
					controller.addNewBarChartView("CountClientsCountEvents");
					// }
				}).start();
			}
		});

		barChartPlatformIDCountEventIDCountMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (controller) {
					controller.addNewBarChartView("CountPlatformsCountEvents");
					// }
				}).start();
			}
		});

		barChartClientIDCountEventIDCountPlatformIDCountTutorIDCount.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (controller) {
					controller.addNewBarChartView("CountAll");
					// }
				}).start();
			}
		});

		newTutorMenuItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					// synchronized (newTutorMenuItem) {
					controller.addNewInsertView("tutor");
					// }
				}).start();

			}

		});

		newClientMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewInsertView("client");
				}).start();

			}

		});

		newTutorPlatformMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewInsertView("platform");
				}).start();
			}
		});

		newTutorEventMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewInsertView("event");
				}).start();
			}
		});

		removeTutorMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewRemoveView("tutor");
				}).start();
			}
		});

		removeClientMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewRemoveView("client");
				}).start();
			}

		});

		removeTutorPlatformMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewRemoveView("platform");
				}).start();
			}
		});

		removeTutorEventMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewRemoveView("event");
				}).start();
			}
		});

		stopwatchMini60MinutesMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewStopwatchMiniView();
				}).start();
			}
		});

		encryptedStorageAddTestMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.addNewEncryptedMessageView();
				}).start();
			}
		});

		encryptedStorageViewTestMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new Thread(() -> {
					controller.viewExistingEncryptedMessageView();
				}).start();
			}
		});

//		encryptedStorageRemoveTestMenuItem.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent arg0) {
//				// TODO Auto-generated method stub
//
//			}
//		});

		menuBar.add(chartMenu);
		menuBar.add(eventMenu);
		menuBar.add(clientMenu);
		menuBar.add(tutorMenu);
		menuBar.add(platformMenu);
		menuBar.add(timerMenu);
		menuBar.add(encryptedStorage);

		controlFrame.setJMenuBar(menuBar);

		countdownButton = new JButton("Go to countdown");
		countdownButton.addActionListener(this);

		JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
		buttonPanel.add(countdownButton);

		// controlPanel.add(buttonPanel);
		controlFrame.add(controlPanel, BorderLayout.CENTER);

		controlFrame.pack();
		controlFrame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	/**
	 * Creates the calendar on Main JPanel... TODO - Line up the month scroller to
	 * be centered on top of the calendar
	 */
	private void initCalendar() {
		calendarMonthJLabel = new JLabel();
		calendar = new GregorianCalendar();

		// label.setHorizontalAlignment(SwingConstants.CENTER);
		// calendarMonthJLabel.setHorizontalAlignment(SwingConstants.CENTER);

		JButton backMonth = new JButton("<<<");

		backMonth.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				calendar.add(Calendar.MONTH, -1);
				updateMonth();
			}
		});

		JButton forwardMonth = new JButton(">>>");
		forwardMonth.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				calendar.add(Calendar.MONTH, +1);
				updateMonth();
			}
		});

//		JPanel panel = new JPanel();
//		panel.setLayout(new BorderLayout());
		controlPanel.add(backMonth, BorderLayout.WEST);
		controlPanel.add(calendarMonthJLabel, BorderLayout.CENTER);
		controlPanel.add(forwardMonth, BorderLayout.EAST);

		String[] columns = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
		calendarTable = new DefaultTableModel(null, columns);
		JTable table = new JTable(calendarTable);
		JScrollPane pane = new JScrollPane(table);

		// controlPanel.add(pane, BorderLayout.NORTH);
		// controlPanel.add(pane, BorderLayout.CENTER);
		controlPanel.add(pane, BorderLayout.CENTER);
		controlPanel.add(table);

		updateMonth();
	}

	private void updateMonth() {
		calendar.set(Calendar.DAY_OF_MONTH, 1);

		String month = calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.US);
		int year = calendar.get(Calendar.YEAR);
		calendarMonthJLabel.setText(month + " " + year);

		int startDay = calendar.get(Calendar.DAY_OF_WEEK);
		int numberOfDays = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		int weeks = calendar.getActualMaximum(Calendar.WEEK_OF_MONTH);

		calendarTable.setRowCount(0);
		calendarTable.setRowCount(weeks);

		int index = startDay - 1;
		for (int day = 1; day <= numberOfDays; day++) {
			calendarTable.setValueAt(day, index / 7, index % 7);
			index++;
		}

	}

}
