package my_mvc;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.RefineryUtilities;

@SuppressWarnings("serial")
public class TutorBarChartTutorEventsCountClientsCountTutorsView extends JFrame implements TutorChart {

	private int clientIDCount = 0, tutorIDCount = 0;
	private TutorControllerTemplate controller;

	public TutorBarChartTutorEventsCountClientsCountTutorsView(String title, TutorControllerTemplate controller) {
		super(title);
		this.setController(controller);
		JFreeChart barChart = ChartFactory.createBarChart(title, "ID type", "Total Count", createDataset());
		ChartPanel chartPanel = new ChartPanel(barChart);
		this.setContentPane(chartPanel);
		this.setDefaultCloseOperation(2);
		this.pack();
		RefineryUtilities.positionFrameRandomly(this);
		this.setVisible(true);
	}

	@Override
	public CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		final String totalTutors = "Total Tutors";
		final String totalClients = "Total Clients";
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		clientIDCount = getController().getClientIDCount();
		tutorIDCount = getController().getTutorIDCount();

		System.out.println("ClientID Count:" + clientIDCount);
		System.out.println("TutorID Count:" + tutorIDCount);

		dataset.addValue(tutorIDCount, totalTutors, totalTutors);
		dataset.addValue(clientIDCount, totalClients, totalClients);

		return dataset;
	}

	public TutorControllerTemplate getController() {
		return controller;
	}

	public void setController(TutorControllerTemplate controller) {
		this.controller = controller;
	}

}
