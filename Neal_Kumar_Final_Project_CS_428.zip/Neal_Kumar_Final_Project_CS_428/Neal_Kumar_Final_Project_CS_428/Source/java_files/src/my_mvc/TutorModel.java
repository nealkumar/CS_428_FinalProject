package my_mvc;

public class TutorModel extends TutorModelTemplate {

	private TutorControllerTemplate controller;

	public TutorControllerTemplate getController() {
		return controller;
	}

	public void setController(TutorControllerTemplate controller) {
		this.controller = controller;
	}

}
