package my_mvc;

import java.util.List;

public abstract class TutorControllerTemplate {

	TutorModelTemplate model;
	TutorView view;

	public TutorControllerTemplate(TutorModelTemplate model) {
		this.model = model;
		view = new TutorView(model, this);
		view.createView();
		view.createControls();
	}

	protected abstract void startBarChartDemo();

	protected final void addNewInsertView(String type) {
		// TODO Auto-generated method stub
		if (type.equals("tutor")) {
			addNewTutorFormView(this);
		} else if (type.equals("client")) {
			addNewClientFormView(this);
		} else if (type.equals("platform")) {
			addNewPlatformFormView(this);
		} else if (type.equals("event")) {
			addNewEventFormView(this);
		}
	}

	protected final void addNewRemoveView(String type) {
		if (type.equals("tutor")) {
			removeExistingTutorFormView(this);
		} else if (type.equals("client")) {
			removeExistingTutorClientFormView(this);
		} else if (type.equals("platform")) {
			removeExistingPlatformFormView(this);
		} else if (type.equals("event")) {
			removeExistingEventFormView(this);
		}
	}

	/**
	 * TODO - Refactor in BarCharViewStrategy
	 * 
	 * @param type
	 */
	protected final void addNewBarChartView(String type) {
		// TODO Auto-generated method stub
		if (type.equals("CountClientsCountTutors")) {
			newCountClientsCountTutorsBarCartView(this);
		} else if (type.equalsIgnoreCase("CountTutorsCountPlatforms")) {
			newCountTutorsCountPlatformsBarCartView(this);
		} else if (type.equalsIgnoreCase("CountTutorsCountEvents")) {
			newCountTutorsCountEventsBarChartView(this);
		} else if (type.equalsIgnoreCase("CountClientsCountPlatforms")) {
			newCountClientsCountPlatformsBarChartView(this);
		} else if (type.equalsIgnoreCase("CountClientsCountEvents")) {
			newCountClientsCountEventsBarChartView(this);
		} else if (type.equalsIgnoreCase("CountPlatformsCountEvents")) {
			newCountPlatformsCountEventsBarChartView(this);
		} else if (type.equalsIgnoreCase("CountAll")) {
			newCountAllBarChartView(this);
		}
	}

	protected final void addNewStopwatchMiniView() {
		newStopwatchMiniView(this);
	}

	protected final void newAddNewServerLoginView() {
		// TODO Auto-generated method stub
		newAddServerLoginView(this);
	}

	protected final void addNewEncryptedMessageView() {
		// TODO Auto-generated method stub
		newAddEncryptedMessageView(this);
	}

	protected final void viewExistingEncryptedMessageView() {
		newViewExistingEncryptedMessageView(this);
	}

	protected abstract void newCountClientsCountTutorsBarCartView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newCountTutorsCountPlatformsBarCartView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newCountTutorsCountEventsBarChartView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newCountClientsCountPlatformsBarChartView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newCountClientsCountEventsBarChartView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newCountPlatformsCountEventsBarChartView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newCountAllBarChartView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void addNewTutorFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void addNewClientFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void addNewPlatformFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void addNewEventFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newAddServerLoginView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void removeExistingEventFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void removeExistingTutorFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void removeExistingTutorClientFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void removeExistingPlatformFormView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newStopwatchMiniView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newAddEncryptedMessageView(TutorControllerTemplate tutorControllerTemplate);

	protected abstract void newViewExistingEncryptedMessageView(TutorControllerTemplate tutorControllerTemplate);

	protected final void insertNewTutor(String firstName, String lastName) {
		// TODO Auto-generated method stub
		model.insertNewTutor(firstName, lastName);
	}

	protected final void removeExistingTutor(String firstName, String lastName) {
		model.deleteExistingTutor(firstName, lastName);
	}

	protected final void removeExistingClient(String firstName, String lastName) {
		model.deleteExistingClient(firstName, lastName);
	}

	protected final void removeExistingPlatform(String platformName, String platformRate) {
		// TODO Auto-generated method stub
		model.deleteExistingPlatform(platformName, platformRate);
	}

	protected final void removeExistingEvent(String eventID) {
		// TODO Auto-generated method stub
		model.deleteExistingEvent(eventID);
	}

	protected final void insertNewClient(String clientFirstName, String clientLastName, String clientRating) {
		// TODO Auto-generated method stub
		model.insertNewClient(clientFirstName, clientLastName, clientRating);
	}

	protected final void insertNewPlatform(String platformName, String platformRate, String platformDescription) {
		// TODO Auto-generated method stub
		model.insertNewPlatform(platformName, platformRate, platformDescription);
	}

	protected final void insertNewEvent(String tutorID, String clientID, String platformID, String tutoringTotalMins,
			String day, String month, String year, String estimatedPay, String estimatedTax) {
		// TODO Auto-generated method stub
		model.insertNewEvent(tutorID, clientID, platformID, tutoringTotalMins, day, month, year, estimatedPay,
				estimatedTax);
	}

	protected final void insertNewEncryptedMessage(String tutorID, String message) {
		// TODO Auto-generated method stub
		model.insertNewEncryptedMessage(tutorID, message);
	}

	protected final int getClientIDCount() {
		// TODO Auto-generated method stub
		return model.getClientIDCount();
	}

	protected final int getTutorIDCount() {
		return model.getTutorIDCount();
	}

	protected final int getPlatformsIDCount() {
		// TODO Auto-generated method stub
		return model.getPlatformIDCount();
	}

	protected final int getEventIDCount() {
		// TODO Auto-generated method stub
		return model.getEventIDCount();
	}

	protected abstract List<String> generateAllTutorsList(List<String> tutorsList, boolean idNumberOnly);

	protected abstract List<String> generateAllTutorClientsList(List<String> clientsList, boolean idNumberOnly);

	protected abstract List<String> generateAllTutorPlatformsList(List<String> platformsList, boolean idNumberOnly);

	protected abstract List<String> generateAllTutoringEventsList(List<String> eventsList, boolean idNumberOnly);

	protected abstract List<String> generateAllEncryptedMessagesList(List<String> messageList, boolean idNumberOnly);

	public final String searchTutorsForFullNameByID(String selectedItem) {
		// TODO Auto-generated method stub
		return model.searchTutorsForFullNameByID(selectedItem);
	}

	public String searchTutorClientsForFullNameByID(String selectedItem) {
		// TODO Auto-generated method stub
		return model.searchTutorClientsForFullNameByID(selectedItem);
	}

	public String searchTutorPlatformsForFullNameByID(String selectedItem) {
		// TODO Auto-generated method stub
		return model.searchTutorPlatformsForFullNameByID(selectedItem);
	}

	protected void setDbUserNameAndPassword(String userName, String password) {
		// TODO Auto-generated method stub
		model.setDbUserNameAndPassword(userName, password);
	}

}
