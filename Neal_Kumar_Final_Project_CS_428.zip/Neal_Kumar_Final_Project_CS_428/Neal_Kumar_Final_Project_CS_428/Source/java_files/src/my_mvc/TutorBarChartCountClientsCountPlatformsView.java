package my_mvc;

import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class TutorBarChartCountClientsCountPlatformsView extends TutorBarChartViewTemplate {

	private int clientIDCount = 0, platformIDCount = 0;
	private static final long serialVersionUID = 1L;

	public TutorBarChartCountClientsCountPlatformsView(String title, TutorControllerTemplate controller) {
		super(title, controller);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		final String totalPlatforms = "Total Platforms";
		final String totalClients = "Total Clients";
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		platformIDCount = getController().getPlatformsIDCount();
		clientIDCount = getController().getClientIDCount();

		dataset.addValue(platformIDCount, totalPlatforms, totalPlatforms);
		dataset.addValue(clientIDCount, totalClients, totalClients);

		return dataset;
	}

}
